Integrating with MyAlerts plugin

1. Open AdminCP -> Templates & Style -> Templates
2. Choose your BootBB templates
3. Find MyAlerts template group and replace the contents of all templates for which there is a corresponding file in the plugin-compatibility/templates folder.
