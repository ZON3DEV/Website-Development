<?php

$l['myalerts_dvz_mentions_post_alert'] = '{1} mentioned you in "{2}".';
$l['myalerts_setting_dvz_mentions_post'] = 'Receive alert when mentioned in a post?';
