<?php

namespace dvzMentions\Alerts\dvzShoutbox;

function alertPossible(array $locationData, int $userId): bool
{
    return true;
}
