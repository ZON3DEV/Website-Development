Thanks for downloading Focus MyBB Theme, created by https://wallbb.co.uk
https://community.mybb.com/mods.php?action=view&pid=671
If you are looking for responsive version, it can be downloaded at 
https://wallbb.co.uk/product/focus-responsive-mybb-theme/

The theme is currently tested till 1.8.22
Installation is simple :-
1. Upload all contents of "Upload" folder in MyBB root
2. Go to Admin CP of MyBB and click on Templates and Style Tab
3. Click on "Import a Theme" Tab and import the Focus-Theme.xml provided with this package.
4. Click on Import Theme after selecting the xml
5. Select Themes from left tab and from Controls on Right side, Set Focus Theme as Default.

Complete documentation is available at
https://wallbb.co.uk/forums/Forum-Theme-Documentation

Enjoy using Focus Theme, in case of any issues contact at
https://community.mybb.com/thread-189771.html
https://wallbb.co.uk/contact-us/

Regards
WallBB
