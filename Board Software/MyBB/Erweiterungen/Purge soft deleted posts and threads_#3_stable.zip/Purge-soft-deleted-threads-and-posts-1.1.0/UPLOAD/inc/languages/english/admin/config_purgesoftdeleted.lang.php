<?php

$l['purgesoftdeleted_name'] = "Purge soft deleted posts and threads";
$l['purgesoftdeleted_desc'] = "Automatically purges soft deleted posts and threads";

$l['purgesoftdeleted_task_name'] = "Purge soft deleted posts and threads";
$l['purgesoftdeleted_task_desc'] = "Checks for soft deleted posts and threads and purges them automatically.";

$l['purgesoftdeleted_task_log'] = "Soft deleted posts and threads now are permanently deleted";