MyBB Prune soft deleted threads and posts
===============================
*Plugin for MyBB 1.8.x created by @Eldenroot /https://community.mybb.com/user-84065.html/ maintained by MyBB Group

Prune soft deleted threads and posts with custom settings for time period for read/unread PMs.
