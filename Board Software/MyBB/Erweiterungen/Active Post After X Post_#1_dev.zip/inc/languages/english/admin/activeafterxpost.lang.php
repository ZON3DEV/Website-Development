<?php

/*
*
* activeafterxpost
* Copyright 2013 mostafa shirali
* http://www.kingofpersia.ir
* No one is authorized to redistribute or remove copyright without my expressed permission.
*
*/

$l['activeafterxpost_plugin_name'] ="Active After X Post";
$l['activeafterxpost_plugin_dec'] = "َAutomatic Active Posts User After X  Active POST";
$l['activeafterxpost_setting_name'] = "َActive After X Post";
$l['activeafterxpost_setting_dec'] = "َActive After X Post Options";


?>