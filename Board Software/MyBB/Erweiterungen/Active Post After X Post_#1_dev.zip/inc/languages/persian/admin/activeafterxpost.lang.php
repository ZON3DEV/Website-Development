<?php

/*
*
* activeafterxpost
* Copyright 2013 mostafa shirali
* http://www.kingofpersia.ir
* No one is authorized to redistribute or remove copyright without my expressed permission.
*
*/


$l['activeafterxpost_plugin_name'] ="فعالسازی ارسال های کاربران پس از  چند پست";
$l['activeafterxpost_plugin_dec'] = "فعالسازی اتوماتیک ارسال های کاربران پس از x پست فعال";
$l['activeafterxpost_setting_name'] = "َفعالسازی ارسال های کاربران پس از  چند پست";
$l['activeafterxpost_setting_dec'] = "تنظیمات";
?>