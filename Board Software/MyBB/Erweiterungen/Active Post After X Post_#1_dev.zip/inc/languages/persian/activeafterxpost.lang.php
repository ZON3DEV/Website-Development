<?php

/*
*
* activeafterxpost
* Copyright 2013 mostafa shirali
* http://www.kingofpersia.ir
* No one is authorized to redistribute or remove copyright without my expressed permission.
*
*/


?>