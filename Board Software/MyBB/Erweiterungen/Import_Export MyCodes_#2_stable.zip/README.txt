## INFORMATION ##

Import/Export MyCodes (1.1) for MyBB 1.8
Created by: Starpaul20
Copyright: �2015
License: GPL

Allows you to export and import MyCodes.

This plugin offers full language support.


## INSTALLATION ##

1. Upload all files above, keeping the file structure intact.
2. Go to Configuration > Plugins
3. Click "Activate"
4. Enjoy!


## UPDATING ##

If you're updating from any previous version, you must first deactivate the plugin, upload all new files and reactivate.