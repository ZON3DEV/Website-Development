<?php
/**
 * German language pack for MyBB 1.8 (formal)
 * Deutsches Sprachpaket für MyBB 1.8 "formell" (Sie)
 * (c) 2005-2014 MyBBoard.de
 * 
 * Author/Autor: http://www.mybboard.de/
 * License/Lizenz: GNU Lesser General Public License, Version 3
 */

$l['bad_words'] = "Wortfilter";
$l['edit_bad_word'] = "Filter bearbeiten";
$l['edit_bad_word_desc'] = "Hier können Sie die Filter und ihre Ersetzungen bearbeiten.";
$l['bad_word_filters'] = "Wortfilter";
$l['bad_word_filters_desc'] = "Diese Funktion erlaubt es Ihnen, einzelne Worte oder Phrasen automatisch ersetzen zu lassen. Dies ist beispielsweise bei Beleidigungen nützlich.";

$l['bad_word'] = "Wort";
$l['bad_word_desc'] = "Geben Sie das Wort ein, das gefiltert werden soll. Ein '*' steht für beliebig viele, ein '+' für ein einzelnes Zeichen (außer Leerzeichen und Zeilenumbrüche).";
$l['bad_word_max'] = "Die Eingabe darf nicht länger als 100 Zeichen sein.";
$l['replacement'] = "Ersetzung";
$l['replacement_desc'] = "Geben Sie die Zeichenfolge ein, durch die das Wort ersetzt werden soll (falls leer, werden Sternchen gezeigt).";
$l['regex'] = "Regulärer Ausdruck";
$l['regex_desc'] = "Verarbeite das \"Wort\" als regulären Ausdruck.";
$l['replacement_word_max'] = "Die Eingabe darf nicht länger als 100 Zeichen lang sein.";
$l['error_replacement_word_invalid'] = "Die Ersetzung darf nicht dem Wort gleichen.";

$l['save_bad_word'] = "Filter speichern";
$l['no_bad_words'] = "Zur Zeit sind keine Wortfilter definiert.";
$l['add_bad_word'] = "Filter hinzufügen";
$l['add_bad_word_desc'] = "Hier können Sie Wortfilter und ihrer Ersetzungen hinzufügen.";

$l['error_missing_bad_word'] = "Sie haben kein Wort zur Filterung angegeben.";
$l['error_invalid_regex'] = "Der angegebene reguläre Ausdruck ist ungültig.";
$l['error_invalid_bid'] = "Der angegebene Filter existiert nicht.";
$l['error_bad_word_filtered'] = "Der angegebene Filter ist bereits ausgeschlossen.";

$l['success_added_bad_word'] = "Der Filter wurde erfolgreich hinzugefügt.";
$l['success_deleted_bad_word'] = "Der Filter wurde erfolgreich gelöscht.";
$l['success_updated_bad_word'] = "Der Filter wurde erfolgreich aktualisiert.";

$l['confirm_bad_word_deletion'] = "Soll dieser Filter wirklich gelöscht werden?";
