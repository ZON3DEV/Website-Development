ALTER TABLE wcf1_page CHANGE style styleID INT(10) NULL DEFAULT NULL;
UPDATE wcf1_page SET styleID = NULL WHERE styleID = 0; /* Update style foreign key for every row to NULL because they were filled with int values before */
ALTER TABLE wcf1_page ADD FOREIGN KEY (styleID) REFERENCES wcf1_style (styleID) ON DELETE SET NULL;