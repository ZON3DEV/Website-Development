CREATE TABLE wcf1_statistics_steam (
    steamhistoryID INT(10) AUTO_INCREMENT PRIMARY KEY,
    steamgameID INT(10) NOT NULL,
    hoursPlayed INT(10) NOT NULL,
    updated date NOT NULL,
    UNIQUE KEY gameHistoryEntry (steamgameID, updated)
);

ALTER TABLE wcf1_statistics_steam ADD FOREIGN KEY (steamgameID) REFERENCES wcf1_steam_integration_game (steamgameID) ON DELETE CASCADE;
