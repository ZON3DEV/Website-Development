INSERT IGNORE INTO wcf1_style_variable (variableName, defaultValue) VALUES ('scFontDisplayGoogle', 'auto');
