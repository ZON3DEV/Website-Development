DROP TABLE IF EXISTS wcf1_style_google_font;
CREATE TABLE wcf1_style_google_font (
    styleGoogleFontID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    internalName VARCHAR(191) NOT NULL,
    popularity INT(10) NOT NULL DEFAULT 0,
    family VARCHAR(191) NOT NULL,
    variants TEXT,
    subsets TEXT,
    lastModified INT(10) NOT NULL DEFAULT 0,
    isVirtual TINYINT(1) NOT NULL DEFAULT 0,
    KEY (popularity),
    UNIQUE KEY internalName (internalName)
);

INSERT IGNORE INTO wcf1_style_variable (variableName, defaultValue) VALUES ('scFontFamilyGoogle', '');
INSERT IGNORE INTO wcf1_style_variable (variableName, defaultValue) VALUES ('scFontDisplayGoogle', 'auto');
