#!/usr/bin/env python
import os, re
import unicodedata

pattern = re.compile('emoji_u(\w+)@2x.png')

smileyConfiguration = open("smiley.xml", "w+")
smileyConfiguration.write('''<?xml version="1.0" encoding="UTF-8"?>
<data xmlns="http://www.woltlab.com" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.woltlab.com http://www.woltlab.com/XSD/tornado/smiley.xsd">
	<import>\n''')

for file in os.listdir("files/images/smilies/noto-emoji"):
	if file.endswith("@2x.png"):
		match = re.search(pattern, file).group(1)
		unicodeCodes = match.split("_")
		smileyConfiguration.write(
'		<smiley name="' + ''.join(map('&#x{0};'.format, unicodeCodes)) + '">\n' +
'			<title>' + file[:-7] + '</title>\n' +
'			<path>images/smilies/noto-emoji/' + file[:-7] + '.png</path>\n' +
'			<path2x>images/smilies/noto-emoji/' + file + '</path2x>\n' +
'		</smiley>\n')


smileyConfiguration.write('''	</import>
</data>\n''')
smileyConfiguration.close()
