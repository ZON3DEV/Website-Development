<?php
/**
 * Defines constants for autocompletion in IDEs. This file is not meant to be actively used anywhere!
 *
 * @author        {COPYRIGHT_AUTHOR}
 * @copyright     {COPYRIGHT_COMPANY}
 * @license       {COPYRIGHT_LICENSE}
 * @package       {COPYRIGHT_PACKAGE}
 * @category      {COPYRIGHT_CATEGORY}
 */

define('WBB_ELITE_WHO_WRITE_SORT', 'Counter DESC');
define('WBB_ELITE_WHO_WRITE_TOP', 0);
define('WBB_ELITE_WHO_WRITE_ON', 0);
define('WBB_ELITE_WHO_WRITE_SORT_SECOND', 'post.username DESC');
define('WBB_ELITE_WHO_WRITE_COUNT', 10);
