ALTER TABLE wcf1_user_group ADD leaderGroupID TEXT NULL;
