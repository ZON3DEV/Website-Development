ALTER TABLE wcf1_user_otu_blacklist_entry CHANGE username username	VARCHAR(100)	NOT NULL;
