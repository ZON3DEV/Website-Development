DROP TABLE IF EXISTS news1_news_to_thread;
CREATE TABLE news1_news_to_thread (
  newsID     INT(10) NOT NULL,
  threadID   INT(10) NOT NULL,
  languageID INT(10) DEFAULT NULL,
  UNIQUE KEY id (newsID, threadID, languageID)
);

ALTER TABLE news1_news_to_thread
  ADD FOREIGN KEY (newsID) REFERENCES news1_news (newsID)
  ON DELETE CASCADE;
ALTER TABLE news1_news_to_thread
  ADD FOREIGN KEY (threadID) REFERENCES wbb1_thread (threadID)
  ON DELETE CASCADE;
ALTER TABLE news1_news_to_thread
  ADD FOREIGN KEY (languageID) REFERENCES wcf1_language (languageID)
  ON DELETE CASCADE;