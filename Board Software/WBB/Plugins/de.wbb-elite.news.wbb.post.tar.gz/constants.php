<?php
/**
 * Defines constants for autocompletion in IDEs. This file is not meant to be actively used anywhere!
 *
 * @author        {COPYRIGHT_AUTHOR}
 * @copyright     {COPYRIGHT_COMPANY}
 * @license       {COPYRIGHT_LICENSE}
 * @package       {COPYRIGHT_PACKAGE}
 * @category      {COPYRIGHT_CATEGORY}
 */

define('DE_WBB_ELITE_NEWS_POST', 0);
define('DE_WBB_ELITE_NEWS_POST_MAKE_ACTION', 0);
define('DE_WBB_ELITE_NEWS_THREAD_AS_NEW', 0);
define('DE_WBB_ELITE_NEWS_SHOW_BUTTON', 1);
