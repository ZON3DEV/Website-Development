ALTER TABLE chat1_message ADD hasEmbeddedObjects TINYINT(1) NOT NULL DEFAULT 0;
