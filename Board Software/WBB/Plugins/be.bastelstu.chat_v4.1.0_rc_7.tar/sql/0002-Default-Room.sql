INSERT INTO chat1_room (title, topic, position) VALUES ('Default', '', 0);
