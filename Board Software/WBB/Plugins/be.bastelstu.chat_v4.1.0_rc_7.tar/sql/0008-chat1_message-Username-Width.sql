ALTER TABLE chat1_message CHANGE username username VARCHAR(100) NOT NULL;
