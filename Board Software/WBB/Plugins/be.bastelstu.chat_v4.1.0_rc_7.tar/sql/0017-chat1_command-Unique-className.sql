ALTER TABLE chat1_command ADD UNIQUE KEY (className);
