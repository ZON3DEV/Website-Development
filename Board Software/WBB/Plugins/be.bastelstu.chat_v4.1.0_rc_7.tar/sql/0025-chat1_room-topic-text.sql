ALTER TABLE chat1_room CHANGE topic topic TEXT NOT NULL;
