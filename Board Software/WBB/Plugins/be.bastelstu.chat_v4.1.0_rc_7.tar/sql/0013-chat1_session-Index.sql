ALTER TABLE chat1_session ADD KEY (lastRequest);
