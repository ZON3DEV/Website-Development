ALTER TABLE chat1_room_to_user CHANGE lastFetch lastPull INT(10) NOT NULL DEFAULT 0;
