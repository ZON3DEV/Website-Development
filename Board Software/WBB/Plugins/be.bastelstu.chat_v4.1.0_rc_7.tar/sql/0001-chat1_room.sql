CREATE TABLE chat1_room ( roomID   INT(10)      NOT NULL AUTO_INCREMENT PRIMARY KEY
                        , title    VARCHAR(255) NOT NULL
                        , topic    VARCHAR(255) NOT NULL
                        , position SMALLINT(5)  NOT NULL
                        );
