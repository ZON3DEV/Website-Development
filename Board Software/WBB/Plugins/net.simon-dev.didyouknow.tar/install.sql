-- did you know entry
DROP TABLE IF EXISTS wcf1_didyouknow;
CREATE TABLE wcf1_didyouknow (
  dykID INT(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  message TEXT NOT NULL,
  isDisabled  tinyint(1) NOT NULL default 0,
  enableSmilies  tinyint(1) NOT NULL default 1,
  enableHtml  tinyint(1) NOT NULL default 0,
  enableBBCodes  tinyint(1) NOT NULL default 1,
  priority tinyint(2) NOT NULL default 1,
  views int(10) NOT NULL default 0,
  useOwnSettings tinyint(1) NOT NULL default 0,
  align ENUM('left','center','right') NULL default 'left',
  KEY dykID (dykID),
) ENGINE=InnoDB;


