<?php
/**
 * Defines constants for autocompletion in IDEs. This file is not meant to be actively used anywhere!
 *
 * @author        Olaf Braun
 * @copyright     2013-2018 Olaf Braun - Software Development
 * @license       
            WBB-Elite.de License <https://lizenz.wbb-elite.de/lizenz.html>
 * @package       de.wbb-elite.donation
 * @category      Donation-System
 */

define('DONATION_BANK_ACTIVE', 0);
DEFINE('DONATION_BANK_TEXT', "");
DEFINE('DONATION_BANK_HOLDER', "");
DEFINE('DONATION_BANK_NUMMBER', "");
DEFINE('DONATION_BANK_BLZ', "");
DEFINE('DONATION_BANK_IBAN', "");
DEFINE('DONATION_BANK_BIC', "");
