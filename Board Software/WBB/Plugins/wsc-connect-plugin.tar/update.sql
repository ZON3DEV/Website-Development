ALTER TABLE wcf1_wsc_connect_notifications CHANGE COLUMN data data MEDIUMTEXT NOT NULL;
